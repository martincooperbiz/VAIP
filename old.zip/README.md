# VAIP

### Introduction
VAIP (Virtual AI Patient) is a project that uses generative AI tools to provide a patient like experience for healthcare providers such as: medical students, doctors ...etc



![preview img](/preview.jpg)
