-Diagnosing 3D model url
https://sketchfab.com/3d-models/low-poly-person-45f547ac6ed54583aa497db938684150


-Surgery 3D model url
https://sketchfab.com/3d-models/patient-00b483f284a542899b94e99831f1ad1c

-Operation bed
https://sketchfab.com/3d-models/sci-fi-operation-table-091fe81b15a9439996dee0ac9f19fed9
